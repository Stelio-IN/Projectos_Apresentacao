<template>
  <IndexVue></IndexVue>
</template>


<script setup>
import IndexVue from "./components/Index.vue";
</script>


<style scoped>
  
</style>
