<template>
    <div class="list-wrapper" ng-app="app" ng-controller="MainCtrl as ctrl">
        <input v-model="name">
        {{ name }}
        <ul class="list" style="max-width: 700px;">
            <template v-for="(nome,index) in listaNomes" :key="index" >
                <UserComponentVue   :user="nome"></UserComponentVue>
            </template>
        </ul>
    </div>
</template>

<script>
import UserComponentVue from './UserComponent.vue'
export default {
    props: ["listaNomes"],
    data() {
        return {
            name: "",
        }
    },
    components: {
        UserComponentVue
    }
}
</script>



<style>
body {
  color: #555;
  background-color: #5B9EED;
  font-family: sans-serif;
}

.list-wrapper {
  max-width: 400px;
  margin: 50px auto;
}

.list {
  background: #fff;
  border-radius: 2px;
  list-style: none;
  padding: 10px 20px;
}

.list-item {
  display: flex;
  margin: 10px;
  padding-bottom: 5px;
  padding-top: 5px;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}
.list-item:last-child {
  border-bottom: none;
}
.list-item-image {
  border-radius: 50%;
  width: 64px;
}
.list-item-content {
  margin-left: 20px;
}
.list-item-content h4, .list-item-content p {
  margin: 0;
}
.list-item-content h4 {
  margin-top: 10px;
  font-size: 18px;
}
.list-item-content p {
  margin-top: 5px;
  color: #aaa;
}
</style>