<template>
    <li class="list-item">
        <div>
            <img :src="user.avatar"
                class="list-item-image">
        </div>
        <div class="list-item-content">
            <h4>{{user.nome}}</h4>
            <p>{{user.email}}</p>
        </div>
    </li>
</template>

<script>
  export default{
    props: ["user"],
    data(){
        return {

        }
    }
  }
</script>


<style></style>