<template>
    <div>
        <UsersListComponentVue :listaNomes="nomes"></UsersListComponentVue>
    </div>
</template>


<script>
import UsersListComponentVue from './UsersListComponent.vue'
    export default{
        data(){
            return {
                contar: 5,
                nomes: [
                    {nome:"Paula", email: "paula@email.com", avatar: "https://plus.unsplash.com/premium_photo-1668383778556-0efac06c34af?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"},
                    {nome:"Pedro", email: "pedro@email.com", avatar:"https://plus.unsplash.com/premium_photo-1668383778556-0efac06c34af?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwyfHx8ZW58MHx8fHx8"},
                    {nome:"Ana", email: "ana@email.com", avatar: "https://images.unsplash.com/photo-1723984834599-5357b87f727c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw4fHx8ZW58MHx8fHx8"}
                ],
                name: "",
            }
        },
        components:{
            UsersListComponentVue
                
        },
        created(){
            console.log("componente criado")
        },
        mounted(){
            console.log("componente montado")
        },
        updated(){
            console.log("componente actualizado")
        },
        unmounted(){
            console.log("componente desmontado")
        }

    }
</script>

<style>
</style>