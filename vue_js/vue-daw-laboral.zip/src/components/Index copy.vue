<template>
    <div>
        <div v-show="false">

        <h1>Estado {{ contar }}</h1>
        <button @click="contar++">Incrementar +</button>
        <button @click="contar--">Decrementar -</button>

        <h1>V-if </h1>
        <HelloWordComponentVue v-if="contar>10"></HelloWordComponentVue>
        <div v-else> Menor que 10</div>
    </div>

        <h1>v-for</h1>
        <input v-model="name">
        <ul>
            <template v-for="(nome, index) in nomes" :key="index">
                <li v-if="nome.includes(name)">{{ nome }}</li>
            </template>
        </ul>

    </div>
</template>


<script>
import HelloWordComponentVue from './HelloWordComponent.vue'
    export default{
        data(){
            return {
                contar: 5,
                nomes: ["Paula", "Pedro", "Ana"],
                name: "",
            }
        },
        components:{
            HelloWordComponentVue
                
        },
        created(){
            console.log("componente criado")
        },
        mounted(){
            console.log("componente montado")
        },
        updated(){
            console.log("componente actualizado")
        },
        unmounted(){
            console.log("componente desmontado")
        }

    }
</script>

<style>
</style>