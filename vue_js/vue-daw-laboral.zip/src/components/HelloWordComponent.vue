<template>
    <div class="div">Ola Mundo! {{ nome }}</div>
</template>

<script>
export default {
    data(){
        return {
            nome: "Joao"
        }
    }
}
</script>

<style>
.div{
    width: 300px;
    height:300px;
    background: #06f;
  }
</style>