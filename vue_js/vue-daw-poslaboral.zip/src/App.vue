<script setup>
// import HelloWorld from './components/HelloWorld.vue'
import IndexComponent from "./components/IndexComponent.vue";
</script>

<template>
  <IndexComponent></IndexComponent>
</template>

<style scoped>

</style>
